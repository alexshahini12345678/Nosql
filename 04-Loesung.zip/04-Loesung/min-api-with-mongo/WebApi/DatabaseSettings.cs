﻿public class DatabaseSettings
{
	// ConnectionString einer MongoDB ist wie folgt aufgebaut:
	// https://www.mongodb.com/docs/drivers/go/current/fundamentals/connection/
	public string ConnectionString { get; set; } = "";
}